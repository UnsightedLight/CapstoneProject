package com.example.iain.culturebot;

import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import org.jeromq.ZMQ;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class GPSMenu extends AppCompatActivity {

    public ZMQ.Context context = ZMQ.context();
    public ZMQ.Socket socket = context.socket(ZMQ.REQ);
    public String address = "";
    public Bundle data = new Bundle();
    public byte[] message = new byte[0];
    public String response = "";
    public Location newLocation = null;
    private static final int ROUTE_MENU_ACTIVITY_REQUEST_CODE = 4;
    private static final int TRACKS_MENU_ACTIVITY_REQUEST_CODE = 6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gpsmenu);
        Intent intent = getIntent();
        Bundle tempData = intent.getExtras();
        if (tempData != null){
            data = tempData;
        }

        TextView textView = findViewById(R.id.textView2);
        textView.setText("No GPX Data");
        try {
            address = data.getString("ip");

        } catch (Throwable ex){

        }


    }

    @Override
    protected void onRestart(){
        super.onRestart();
        address = data.getString("ip");
    }

    @Override //onActivityResults() calls before onRestart()
    protected void onActivityResult(int requestCode, int resultCode, Intent returnData){

        super.onActivityResult(requestCode, resultCode, returnData);
        if (requestCode == ROUTE_MENU_ACTIVITY_REQUEST_CODE){
            if (resultCode == RESULT_OK) {
                Bundle tempBundle = returnData.getExtras();
            }
        }

    }

    public void gotoRoutes(View view){
        Intent route_intent = new Intent(this, RoutesMenu.class);
        route_intent.putExtras(data);
        startActivityForResult(route_intent, ROUTE_MENU_ACTIVITY_REQUEST_CODE);

    }

    public void gotoTracks(View view){

        Intent tracks_intent = new Intent(this, TracksMenu.class);
        tracks_intent.putExtras(data);
        startActivityForResult(tracks_intent, TRACKS_MENU_ACTIVITY_REQUEST_CODE);
    }

    public void makeRoute(View view){

        JSONObject new_route_request = new JSONObject();
        try{
            new_route_request.put("service", "gpsexchange");
            new_route_request.put("function", "newRoute");
            JSONArray arr = new JSONArray();
            new_route_request.put("args", arr);
        } catch (JSONException ex) {
            ex.printStackTrace();
        }

        socket.setSendTimeOut((1000));
        socket.setReceiveTimeOut((2000));
        socket.connect("tcp://" + address + ":5600");
        socket.send(new_route_request.toString());
        byte[] byteResponse = socket.recv();
        if (byteResponse != null){
            Toast.makeText(GPSMenu.this, "Created New Route", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(GPSMenu.this, "Timeout", Toast.LENGTH_SHORT).show();
        }

    }

    public void connectionTest(View view){

        JSONObject connectionTest = new JSONObject();
        try{
            connectionTest.put("service", "connectionTest");
            connectionTest.put("function", "readRoute");
            JSONArray arr = new JSONArray();
            connectionTest.put("args", arr);
        } catch (JSONException ex) {
            ex.printStackTrace();
        }

        socket.setSendTimeOut((1000));
        socket.setReceiveTimeOut((2000));
        socket.connect("tcp://" + address + ":5600");
        socket.send(connectionTest.toString());
        byte[] byteResponse = socket.recv();
        if (byteResponse != null){
                TextView textView = findViewById(R.id.textView2);
                textView.setText("Connected");

        }
        else {
            TextView textView = findViewById(R.id.textView2);
            textView.setText("Connection Failed");
        }

    }


}
