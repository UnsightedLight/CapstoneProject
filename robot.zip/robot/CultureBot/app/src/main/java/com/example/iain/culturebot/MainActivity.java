package com.example.iain.culturebot;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.content.SharedPreferences;
import android.widget.Toast;

import org.jeromq.ZMQ;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    // Class Variables
    public Bundle appData = new Bundle();
    SharedPreferences sharedPreferences;
    private static final int NETWORK_MENU_ACTIVITY_REQUEST_CODE = 0;
    private static final int GPS_MENU_ACTIVITY_REQUEST_CODE = 1;
    private static final int OPERATION_MODE_ACTIVITY_REQEST_CODE = 2;
    private static final int VIDEO_FEED_ACTIVITY_REQUEST_CODE = 3;
    private static final int ROUTE_MENU_ACTIVITY_REQUEST_CODE = 4;
    private static final int ROUTE_VIEW_ACTIVITY_REQUEST_CODE = 5;
    private static final int TRACKS_MENU_ACTIVITY_REQUEST_CODE = 6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (savedInstanceState != null){
            appData.putString("ip", savedInstanceState.getString("ip"));
        }

        else {
            appData.putString("ip", "10.0.0.100");
        }

        if(!runtime_permissions()){
        }

        Intent i = new Intent(getApplicationContext(), GPS_Service.class);
        startService(i);

    }

    private boolean runtime_permissions() {
        if(Build.VERSION.SDK_INT >= 23 && ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 100);
            return true;
        }
        return false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 100) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {

            }
            else{
                runtime_permissions();
            }


        }
    }

    @Override
    public void onRestart()
    {
        super.onRestart();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("ip", appData.getString("ip"));

    }


    @Override //onActivityResults() calls before onRestart()
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == NETWORK_MENU_ACTIVITY_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                Bundle tempBundle = data.getExtras();
                appData.putString("ip", tempBundle.getString("ip"));
            }
        }
        if (requestCode == GPS_MENU_ACTIVITY_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                Bundle tempBundle = data.getExtras();
            }
        }
        if (requestCode == OPERATION_MODE_ACTIVITY_REQEST_CODE) {
            if (resultCode == RESULT_OK) {
                Bundle tempBundle = data.getExtras();
            }
        }
    }

    public void gotoNetworkMenu(View view){
        Intent network_intent = new Intent(this, NetworkMenu.class);
        network_intent.putExtras(appData);
        startActivityForResult(network_intent, NETWORK_MENU_ACTIVITY_REQUEST_CODE);

    }

    public void gotoGPSMenu (View view){
        Intent gps_intent = new Intent(this, GPSMenu.class);
        gps_intent.putExtras(appData);
        startActivityForResult(gps_intent, GPS_MENU_ACTIVITY_REQUEST_CODE);
    }

    public void gotoOperationMode(View View){
        Intent operation_intent = new Intent(this, OperationMode.class);
        operation_intent.putExtras(appData);
        startActivityForResult(operation_intent, OPERATION_MODE_ACTIVITY_REQEST_CODE);
    }

    public void gotoVideoFeed(View view){
        Intent myIntent = new Intent(MainActivity.this, Show.class);
        startActivity(myIntent);
    }

    public void setOperationModeFollow(View view){

        ZMQ.Context context = ZMQ.context();
        ZMQ.Socket socket = context.socket(ZMQ.REQ);
        String address = appData.getString("ip");
        JSONObject setFollow = new JSONObject();

        try{
            setFollow.put("service", "setOPMode");
            setFollow.put("function", "set_follow_device");
            JSONArray arr = new JSONArray();
            setFollow.put("args", arr);
        } catch (JSONException ex) {
            ex.printStackTrace();
        }

        socket.connect("tcp://" + address + ":5600");
        socket.setSendTimeOut((1000));
        socket.setReceiveTimeOut((2000));
        socket.send(setFollow.toString());
        byte[] byteResponse = socket.recv();

        if (byteResponse != null) {
            Toast.makeText(MainActivity.this, "Follow Device Set", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(MainActivity.this, "Timeout", Toast.LENGTH_SHORT).show();
        }

    }

    public void setOperationModeStop(View view){

        ZMQ.Context context = ZMQ.context();
        ZMQ.Socket socket = context.socket(ZMQ.REQ);
        String address = appData.getString("ip");
        JSONObject setStop = new JSONObject();

        try{
            setStop.put("service", "setOPMode");
            setStop.put("function", "set_stop");
            JSONArray arr = new JSONArray();
            setStop.put("args", arr);
        } catch (JSONException ex) {
            ex.printStackTrace();
        }

        socket.connect("tcp://" + address + ":5600");
        socket.setSendTimeOut((1000));
        socket.setReceiveTimeOut((2000));
        socket.send(setStop.toString());
        byte[] byteResponse = socket.recv();

        if (byteResponse != null) {
            Toast.makeText(MainActivity.this, "Stopping", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(MainActivity.this, "Timeout", Toast.LENGTH_SHORT).show();
        }

    }
}


