package com.example.iain.culturebot;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class NetworkMenu extends AppCompatActivity {

    public Bundle data = new Bundle();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        data = intent.getExtras();
        setContentView(R.layout.activity_network_menu);
        EditText editText = (EditText) findViewById(R.id.editText);
        editText.setText(data.getString("ip"));
    }


    public void returnFromNetworkMenu(View view){

        EditText editText = (EditText) findViewById(R.id.editText);
        data.putString("ip", editText.getText().toString());
        Intent newIntent = new Intent();
        newIntent.putExtras(data);

        setResult(RESULT_OK, newIntent);
        finish();

    }
}
