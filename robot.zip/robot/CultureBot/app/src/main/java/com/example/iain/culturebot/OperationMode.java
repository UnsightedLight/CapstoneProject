package com.example.iain.culturebot;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import org.jeromq.ZMQ;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class OperationMode extends AppCompatActivity {

    public Bundle data = new Bundle();
    public ZMQ.Context context = ZMQ.context();
    public ZMQ.Socket socket = context.socket(ZMQ.REQ);
    public String address;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_operation_mode);
        Intent intent = getIntent();
        data = intent.getExtras();
        address = data.getString("ip");
        socket.connect("tcp://" + address + ":5600");
    }

    public void setNavigationOnly (View view) {

        JSONObject setOperationMode = new JSONObject();

        try{
            setOperationMode.put("service", "setOPMode");
            setOperationMode.put("function", "set_navigation_only");
            JSONArray arr = new JSONArray();
            setOperationMode.put("args", arr);
        } catch (JSONException ex) {
            ex.printStackTrace();
        }

        socket.connect("tcp://" + address + ":5600");
        socket.setSendTimeOut((1000));
        socket.setReceiveTimeOut((1000));
        socket.send(setOperationMode.toString());
        byte[] byteResponse = socket.recv();

        if (byteResponse != null) {
            Toast.makeText(OperationMode.this, "Set Navigation Only", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(OperationMode.this, "Timeout", Toast.LENGTH_SHORT).show();
        }

    }

    public void setNavigationAndData(View view){

        JSONObject setOperationMode = new JSONObject();

        try{
            setOperationMode.put("service", "setOPMode");
            setOperationMode.put("function", "set_navigation_and_data");
            JSONArray arr = new JSONArray();
            setOperationMode.put("args", arr);
        } catch (JSONException ex) {
            ex.printStackTrace();
        }

        socket.connect("tcp://" + address + ":5600");
        socket.setSendTimeOut((1000));
        socket.setReceiveTimeOut((1000));
        socket.send(setOperationMode.toString());
        byte[] byteResponse = socket.recv();

        if (byteResponse != null) {
            Toast.makeText(OperationMode.this, "Set Navigation and Data", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(OperationMode.this, "Timeout", Toast.LENGTH_SHORT).show();
        }

    }

    public void setNavigationAndDetect(View view){

        JSONObject setOperationMode = new JSONObject();

        try{
            setOperationMode.put("service", "setOPMode");
            setOperationMode.put("function", "set_navigation_and_detect");
            JSONArray arr = new JSONArray();
            setOperationMode.put("args", arr);
        } catch (JSONException ex) {
            ex.printStackTrace();
        }

        socket.connect("tcp://" + address + ":5600");
        socket.setSendTimeOut((1000));
        socket.setReceiveTimeOut((1000));
        socket.send(setOperationMode.toString());
        byte[] byteResponse = socket.recv();

        if (byteResponse != null) {
            Toast.makeText(OperationMode.this, "Set Navigation and Detect", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(OperationMode.this, "Timeout", Toast.LENGTH_SHORT).show();
        }

    }

    public void setNavigationAndWeed(View view){

        JSONObject setOperationMode = new JSONObject();

        try{
            setOperationMode.put("service", "setOPMode");
            setOperationMode.put("function", "set_navigation_and_weed");
            JSONArray arr = new JSONArray();
            setOperationMode.put("args", arr);
        } catch (JSONException ex) {
            ex.printStackTrace();
        }

        socket.connect("tcp://" + address + ":5600");
        socket.setSendTimeOut((1000));
        socket.setReceiveTimeOut((1000));
        socket.send(setOperationMode.toString());
        byte[] byteResponse = socket.recv();

        if (byteResponse != null) {
            Toast.makeText(OperationMode.this, "Set Navigation and Weed", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(OperationMode.this, "Timeout", Toast.LENGTH_SHORT).show();
        }

    }

}
