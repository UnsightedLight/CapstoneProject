package com.example.iain.culturebot;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.app.Activity;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import org.jeromq.ZMQ;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import static android.os.SystemClock.sleep;

public class RouteView extends Activity {

    public Bundle data = new Bundle();
    public ZMQ.Context context = ZMQ.context();
    public ZMQ.Socket socket = context.socket(ZMQ.REQ);
    public ZMQ.Socket socket2 = context.socket(ZMQ.SUB);
    public String address;
    public int routeName;
    public JSONObject route_request = new JSONObject();
    public JSONArray route = new JSONArray();
    public String[] list;
    public BroadcastReceiver broadcastReceiver;
    public Object coordinates;
    public String longitude;
    public String latitude;
    public String altitude;
    boolean pushingDown = false;
    Handler handler = new Handler();
    Runnable repeater = new Runnable(){

        @Override public void run() {
            continuousAddPoints();
            if (pushingDown) {
                handler.postDelayed(this, 1000);
            }

        }

    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        System.out.println("onDestroy");
        if(broadcastReceiver != null){
            unregisterReceiver(broadcastReceiver);
        }
    }



    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_route_view);
        Intent intent = getIntent();
        data = intent.getExtras();
        routeName = data.getInt("routeNumber");
        address = data.getString("ip");

        if(broadcastReceiver == null){
            broadcastReceiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {

                    longitude = intent.getExtras().get("Longitude").toString();
                    latitude = intent.getExtras().get("Latitude").toString();
                    altitude = intent.getExtras().get("Altitude").toString();

                }
            };

        registerReceiver(broadcastReceiver, new IntentFilter("location_update"));

        }

        getRoute();
        updateRoute();

        Button cont = findViewById(R.id.button17);
        cont.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch(motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        //Pressed down
                        if (pushingDown == false) {
                            Toast.makeText(RouteView.this, "Tracking", Toast.LENGTH_SHORT).show();
                        }
                        pushingDown = true;
                        handler.post(repeater);

                        return true;

                    case MotionEvent.ACTION_UP:
                        //Released
                        Toast.makeText(RouteView.this, "Stopped Tracking", Toast.LENGTH_SHORT).show();
                        pushingDown = false;
                        return true;

                    case MotionEvent.ACTION_CANCEL:
                        //Released
                        Toast.makeText(RouteView.this, "Stopped Tracking", Toast.LENGTH_SHORT).show();
                        pushingDown = false;
                        return true;

                }

                return false;
            }
        });


    }


    public void updateRoute(){

        list = new String[route.length()];
        for (int i = 0; i < route.length(); i++) {

            try {
                list[i] = route.getString(i);
            } catch (JSONException ex) {
                ex.printStackTrace();
            }

        }

        ListView listView = (ListView) findViewById(R.id.list_view2);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list);
        listView.setAdapter(adapter);

    }

    public void getRoute(){

        try{
            route_request.put("service", "gpsexchange");
            route_request.put("function", "readRoute");
            JSONArray arr = new JSONArray();
            arr.put(routeName);
            route_request.put("args", arr);
        } catch (JSONException ex) {
            ex.printStackTrace();
        }

        socket.setSendTimeOut((1000));
        socket.setReceiveTimeOut((2000));
        socket.connect("tcp://" + address + ":5600");
        socket.send(route_request.toString());
        byte[] byteResponse = socket.recv();
        if (byteResponse != null){
            try {
                String responce = new String(byteResponse);
                route = new JSONArray(responce);
            } catch (JSONException ex) {
                Toast.makeText(RouteView.this, "Timeout", Toast.LENGTH_SHORT).show();
            }

        }

    }

    public void addRoutePoint(View view){

        if(latitude != null){

            JSONObject addRoutePoint = new JSONObject();

            try{
                addRoutePoint.put("service", "gpsexchange");
                addRoutePoint.put("function", "newRoutePoint");
                JSONArray arr = new JSONArray();
                arr.put(latitude);
                arr.put(longitude);
                arr.put(altitude);
                arr.put(routeName);
                addRoutePoint.put("args", arr);
            } catch (JSONException ex) {
                ex.printStackTrace();
            }


            socket.setSendTimeOut((1000));
            socket.setReceiveTimeOut((2000));

            socket.connect("tcp://" + address + ":5600");
            socket.send(addRoutePoint.toString());
            byte[] byteResponse = socket.recv();
            if (byteResponse != null){

                String responce = new String(byteResponse);
                Toast.makeText(RouteView.this, responce, Toast.LENGTH_SHORT).show();
                getRoute();
                updateRoute();

            }

            else{
                Toast.makeText(RouteView.this, "Timeout", Toast.LENGTH_SHORT).show();
            }
        }

        else{
            Toast.makeText(RouteView.this, "Connnecting to GPS, Try Again", Toast.LENGTH_SHORT).show();
        }


    }


    public void continuousAddPoints(){

        if(latitude != null){

            JSONObject addRoutePoint = new JSONObject();

            try{
                addRoutePoint.put("service", "gpsexchange");
                addRoutePoint.put("function", "newRoutePoint");
                JSONArray arr = new JSONArray();
                arr.put(latitude);
                arr.put(longitude);
                arr.put(altitude);
                arr.put(routeName);
                addRoutePoint.put("args", arr);
            } catch (JSONException ex) {
                ex.printStackTrace();
            }


            socket.setSendTimeOut((1000));
            socket.setReceiveTimeOut((2000));

            socket.connect("tcp://" + address + ":5600");
            socket.send(addRoutePoint.toString());
            byte[] byteResponse = socket.recv();
            if (byteResponse != null){

                String responce = new String(byteResponse);
                getRoute();
                updateRoute();

            }

            else{
                Toast.makeText(RouteView.this, "Timeout", Toast.LENGTH_SHORT).show();
            }
        }

        else{
            Toast.makeText(RouteView.this, "Connnecting to GPS, Try Again", Toast.LENGTH_SHORT).show();
        }


    }
}
