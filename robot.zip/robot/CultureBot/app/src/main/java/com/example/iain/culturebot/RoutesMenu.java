package com.example.iain.culturebot;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import org.jeromq.ZMQ;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class RoutesMenu extends AppCompatActivity {

    public Bundle data = new Bundle();
    public ZMQ.Context context = ZMQ.context();
    public ZMQ.Socket socket = context.socket(ZMQ.REQ);
    public String address;
    private static final int ROUTE_VIEW_ACTIVITY_REQUEST_CODE = 4;
    public JSONObject routes_request = new JSONObject();
    public JSONArray routes = new JSONArray();
    public String[] list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_routes_menu);
        Intent intent = getIntent();
        data = intent.getExtras();
        try {
            address = data.getString("ip");

        } catch (Throwable ex){

        }
        getRoutes();

        list = new String[routes.length()];
        for (int i = 0; i < routes.length(); i++) {

            try {
                list[i] = routes.getString(i);
            } catch (JSONException ex) {
                ex.printStackTrace();
            }

        }


        ListView listView = (ListView) findViewById(R.id.list_view);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //This area is called when an item on the list is clicked
                //Toast.makeText(RoutesMenu.this, list[i], Toast.LENGTH_SHORT).show();

                gotoViewRoute(i);

            }
        });

    }

    @Override
    public void onBackPressed(){

        super.onBackPressed();
        Intent newIntent = new Intent();
        newIntent.putExtras(data);
        setResult(RESULT_OK, newIntent);
        finish();


    }

    @Override
    public void finish(){
        Intent newIntent = new Intent();
        Toast.makeText(RoutesMenu.this, data.getString("ip"), Toast.LENGTH_SHORT).show();
        newIntent.putExtras(data);
        setResult(RESULT_OK, newIntent);
        super.finish();

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){

        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ROUTE_VIEW_ACTIVITY_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                Bundle tempBundle = data.getExtras();
            }
        }


    }

    public void gotoViewRoute(int routeNumber){
        Intent route_intent = new Intent(this, RouteView.class);
        data.putInt("routeNumber", routeNumber);
        route_intent.putExtras(data);
        startActivityForResult(route_intent, ROUTE_VIEW_ACTIVITY_REQUEST_CODE);

    }

    public void getRoutes(){

        try{
            routes_request.put("service", "gpsexchange");
            routes_request.put("function", "listRoutes");
            JSONArray arr = new JSONArray();
            routes_request.put("args", arr);
        } catch (JSONException ex) {
            ex.printStackTrace();
        }

        Toast.makeText(RoutesMenu.this, address, Toast.LENGTH_SHORT).show();
        socket.connect("tcp://" + address + ":5600");
        socket.setSendTimeOut((1000));
        socket.setReceiveTimeOut((1000));
        socket.send(routes_request.toString());
        byte[] byteResponse = socket.recv();

        if (byteResponse != null) {
            try {
                String responce = new String(byteResponse);
                routes = new JSONArray(responce);
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
        }
        else {
            Toast.makeText(RoutesMenu.this, "Timeout", Toast.LENGTH_SHORT).show();
        }

    }

}
