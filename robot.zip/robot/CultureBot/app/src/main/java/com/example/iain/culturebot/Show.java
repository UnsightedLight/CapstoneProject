package com.example.iain.culturebot;

import android.app.Activity;
import android.app.ProgressDialog;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.MediaController;
import android.widget.VideoView;

public class Show extends Activity {
    ProgressDialog pd;
    VideoView view;
    String URL = "https://raw.githubusercontent.com/rubu/WebMPlayer/master/Samples/big_buck_bunny_live.webm";
    //https://raw.githubusercontent.com/rubu/WebMPlayer/master/Samples/big_buck_bunny_live.webm
    //http://192.168.43.142:8080/stream?topic=/camera/image_raw&type=vp8
    /* (non-Javadoc) * @see android.app.Activity#onCreate(android.os.Bundle)*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);
        view = (VideoView)findViewById(R.id.videoView1);


        try{

            MediaController controller = new MediaController(Show.this);
            controller.setAnchorView(view);
            Uri vid = Uri.parse(URL);
            view.setMediaController(controller);
            view.setVideoURI(vid);
        }catch(Exception e){
            Log.e("Error", e.getMessage());
            e.printStackTrace();
        }
        view.requestFocus();
        view.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            public void onPrepared(MediaPlayer mp) {
                //pd.dismiss();
                view.start();
            }
        });
    }
}