package com.example.iain.culturebot;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import org.jeromq.ZMQ;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class TracksMenu extends AppCompatActivity {

    public Bundle data = new Bundle();
    public ZMQ.Context context = ZMQ.context();
    public ZMQ.Socket socket = context.socket(ZMQ.REQ);
    public String address;
    private static final int ROUTE_VIEW_ACTIVITY_REQUEST_CODE = 4;
    public JSONObject tracks_request = new JSONObject();
    public JSONArray tracks = new JSONArray();
    public String[] list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tracks_menu);
        Intent intent = getIntent();
        data = intent.getExtras();
        try {
            address = data.getString("ip");

        } catch (Throwable ex) {

        }

        getTracks();
        updateRoute();

    }

    public void updateRoute(){


        list = new String[tracks.length()];
        for (int i = 0; i < tracks.length(); i++) {

            try {
                list[i] = tracks.getString(i);
            } catch (JSONException ex) {
                ex.printStackTrace();
            }

        }

        ListView listView = (ListView) findViewById(R.id.list_view3);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list);
        listView.setAdapter(adapter);

    }

    public void getTracks(){

        try{
            tracks_request.put("service", "gpsexchange");
            tracks_request.put("function", "readTrack");
            JSONArray arr = new JSONArray();
            tracks_request.put("args", arr);
        } catch (JSONException ex) {
            ex.printStackTrace();
        }

        Toast.makeText(TracksMenu.this, address, Toast.LENGTH_SHORT).show();
        socket.connect("tcp://" + address + ":5600");
        socket.setSendTimeOut((1000));
        socket.setReceiveTimeOut((1000));
        socket.send(tracks_request.toString());
        byte[] byteResponse = socket.recv();

        if (byteResponse != null) {
            try {
                String responce = new String(byteResponse);
                tracks = new JSONArray(responce);
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
        }
        else {
            Toast.makeText(TracksMenu.this, "Timeout", Toast.LENGTH_SHORT).show();
        }

    }
}
